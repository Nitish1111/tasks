var express = require('express');
var app = express();
//var cors = require('cors');
const port = 3000;

var users = require('./routes/usersRoutes');

var bodyparser = require('body-parser');
app.use(express.static(__dirname));
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }));
//app.use(cors());

//app.use('/admin', admin);
//app.use('/critEvents', critEvents);

app.use('/users', users);




app.listen(port, function () { console.log('started at '+port); })