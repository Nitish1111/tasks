const fs = require('fs');
const promise = require('promise');
const userFile  =require('../user.json');
const userRole  =require('../userRoles.json');


exports.insertUser = function (req,res,callback) {
    //console.log(req);

    
    readUserData('./user.json', 'utf8')
        .then(result=> {
            result = JSON.parse(result);
           // console.log(result);
            if(!result || result.length == 0){
                 //let dummyUser = {role:14,uname:"abc",age:25,email:"abc@abc.com"};
                 req.role = 13;
                let data = [req];
                writeUserData('./user.json',JSON.stringify(data))

            }
            else{
                //let dummyUser = {role:14,uname:"abc",age:25,email:"abc@abc.com"};
                req.role = 12;
                result.push(req);
                writeUserData('./user.json',JSON.stringify(result))
            }    
        })
        .then(
            result=> callback(null,result)
        )
        .catch(err=>callback(err));
    
    

}

const readUserData  = function(fileName,type){
    return new Promise(function(resolve, reject){
        fs.readFile(fileName, type, (err, data) => {
            err ? reject(err) : resolve(data);
        });
      });

}

const writeUserData  = function(fileName,type){
    return new Promise(function(resolve, reject){
        fs.writeFile(fileName, type, (err, data) => {
            err ? reject(err) : resolve(data);
        });
      });

}
