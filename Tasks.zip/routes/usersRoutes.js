var express = require('express')
var router = express.Router();
var user = require('../controller/userController');

router.post('/insertUser',user.insertUser);
//router.get('/getUserList',user.getUserList)


module.exports = router;
